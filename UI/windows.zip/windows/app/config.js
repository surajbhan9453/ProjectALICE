'use strict';
exports.id = 'com.puupnewsapp';
exports.version = '0.9.0';
exports.ids = {
  chrome: [
    'lcdlanlaneooailnebnhamiiieebikid',  // download-by-idm (chrome)
  ],
  firefox: [
    '{a5b9ddb4-102b-440d-82c1-05aee905619e}', // download-by-fdm
  ]
};